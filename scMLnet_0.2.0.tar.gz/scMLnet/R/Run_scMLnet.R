# get barcode list of cluster of interset and other cluster
getBarList <- function(Aclu, GCMat, BarCluTable)
{
  AcluBar <- BarCluTable %>% filter(.,Cluster == Aclu) %>% select(.,Barcode) %>% unlist()
  names(AcluBar) <- NULL

  AllBar <- BarCluTable %>% select(Barcode) %>% unlist()
  OtherBar <- setdiff(AllBar,AcluBar)

  result <- list(AcluBar,OtherBar)
  return(result)
}

# perform fisher test to get activate TFs or pathways
fisher_test <- function(subset1,subset2,backgrond)
{
  a=length(intersect(subset1,subset2))
  b=length(subset1)-a
  c=length(subset2)-a
  d=length(backgrond)-a-b-c
  matrix=matrix(c(a,c,b,d),nrow=2)
  stats::fisher.test(matrix,alternative="greater")$p.value
}

# get nodes in prior Database
getNodeList <- function(Database, Nodetype)
{

  NodeList <- Database[,Nodetype] %>% unlist() %>% unique()

  return(NodeList)

}

runNormalize <- function(GCMat, norm.method = "LogNormalize")
{

  if (!(norm.method %in% c("LogNormalize", "CLR", "RC", "SCTransform")))
    stop("wrong normalization method!")

  seur = CreateSeuratObject(counts = GCMat)

  if(norm.method == "SCTransform") {
    seur = SCTransform(seur, verbose = TRUE)
    GCMat = seur@assays$SCT@data
  }else {
    seur = NormalizeData(seur, normalization.method = norm.method, verbose = TRUE)
    GCMat = seur@assays$RNA@data
  }

  return(GCMat)
}

getDiffExpGene <- function(GCMat, BarCluTable, Clus, min_pct = 0.1, min_diff.pct = -Inf,
                           logfc.cutoff = 0.25, p_val.cutoff = 0.05, Test.methods = "t")
{

  if (!is.logical(Raw.data) | length(Raw.data) != 1)
    stop("Raw.data must be a logical vector of length 1")
  if (p_val.cutoff < 0 | p_val.cutoff > 1)
    stop("p_val.cutoff must be a number between 0 and 1 (0 and 1 included)")
  if (!(Test.methods %in% c("wilcox", "bimod", "roc", "t", "MAST", "LR")))
    stop("wrong test method!")

  ## get barcode
  BarListResult <- getBarList(Aclu = Clus, GCMat, BarCluTable)
  Clus.1 <- BarListResult[[1]]
  Clus.2 <- BarListResult[[2]]

  ## find DEGs(use all other cells for FindMarkers)
  cat(paste0("get differentially expressed genes in ",Clus,"\n"))
  DEGs <- FindMarkers(object = GCMat, cells.1 = Clus.1, cells.2 = Clus.2, logfc.threshold = logfc.cutoff,
                      min.pct = min_pct, min.diff.pct = min_diff.pct, test.use = Test.methods, verbose = T)

  ## output
  up_gene <- DEGs %>% filter(p_val_adj <= p_val.cutoff & avg_logFC > 0) %>% rownames()
  #cat(paste0("find up-regulated genes: ",length(up_gene),"\n"))
  down_gene <- DEGs %>% filter(p_val_adj <= p_val.cutoff & avg_logFC < 0) %>% rownames()
  #cat(paste0("find down-regulated genes: ",length(down_gene),"\n"))

  return(DEGs)

}

getLigRec <- function(LigRec.DB, source_up, target_up)
{

  if (!is.data.frame(LigRec.DB))
    stop("LigRec.DB must be a data frame or tibble object")
  if (!"source" %in% colnames(LigRec.DB))
    stop("LigRec.DB must contain a column named 'source'")
  if (!"target" %in% colnames(LigRec.DB))
    stop("LigRec.DB must contain a column named 'target'")

  # get ligand and receptor list
  LigGene <- LigRec.DB %>% select(source) %>% unlist() %>% unique()
  RecGene <- LigRec.DB %>% select(target) %>% unlist() %>% unique()
  TotLigRec <- paste(LigRec.DB$source, LigRec.DB$target, sep = "_") %>% unique()

  # get high expressed ligand and receptor
  LigHighGene <- intersect(LigGene,source_up)
  RecHighGene <- intersect(RecGene,target_up)

  # get activated LR pairs
  LRList <- paste(rep(LigHighGene,each = length(RecHighGene)),RecHighGene,sep = "_")
  LRList <- intersect(LRList,TotLigRec)

  # check result
  if(length(LRList)==0)
    stop("Error: No significant LigRec pairs")

  # get result
  LRTable <- LRList %>% strsplit(.,split = "_") %>% do.call(rbind, .) %>% as.data.frame()
  colnames(LRTable) <- c("source","target")

  cat(paste0("get ",length(LRList)," activated LR pairs\n"))
  return(LRTable)

}

getTFTG <- function(TFTG.DB, target.degs, target.genes)
{

  if (!is.data.frame(TFTG.DB))
    stop("TFTG.DB must be a data frame or tibble object")
  if (!"source" %in% colnames(TFTG.DB))
    stop("TFTG.DB must contain a column named 'source'")
  if (!"target" %in% colnames(TFTG.DB))
    stop("TFTG.DB must contain a column named 'target'")

  # get TF list
  TF.list <- TFTG.DB %>% select(source) %>% unlist() %>% unique()

  # get Target list
  TG.list <- lapply(TF.list, function(x){
    TFTG.DB %>% filter(source == x)  %>% select(target) %>% unlist() %>% unique()
  })
  names(TG.list) <- TF.list

  # get target differently expressed genes
  DEGs <- target.degs

  # perform fisher test
  TFs <- lapply(TG.list, function(x){fisher_test(subset1 = x, subset2 = DEGs, backgrond = target.genes)})
  TFs <- unlist(TFs)
  TFs <- names(TFs)[TFs <= 0.05]
  TFs <- TFs[TFs %in% target.genes]

  # get activated LR pairs
  TFTGList <- TG.list[TFs]
  TFTGList <- lapply(TFTGList, function(x){intersect(x, DEGs)})
  TFTGList <- paste(rep(TFs, times = lengths(TFTGList)), unlist(TFTGList), sep = "_")

  # check result
  if(length(TFTGList)==0)
    stop("Error: No significant TFTG pairs")

  # get result
  TFTGTable <- TFTGList %>% strsplit(.,split = "_") %>% do.call(rbind, .) %>% as.data.frame()
  colnames(TFTGTable) <- c("source","target")

  cat(paste0("get ",length(TFTGList)," activated TFTG pairs\n"))
  return(TFTGTable)

}

getRecTF <- function(RecTF.DB, Rec.list, TF.list, target_gene)
{

  if (!is.data.frame(RecTF.DB))
    stop("RecTF.DB must be a data frame or tibble object")
  if (!"source" %in% colnames(RecTF.DB))
    stop("RecTF.DB must contain a column named 'source'")
  if (!"target" %in% colnames(RecTF.DB))
    stop("RecTF.DB must contain a column named 'target'")

  # make sure Rec.list in RecTF.DB
  Rec.list <- Rec.list[Rec.list %in% RecTF.DB$source]
  Rec.list <- as.vector(Rec.list)

  # get TF activated by Receptors
  TFofRec <- lapply(Rec.list, function(x){
    RecTF.DB %>% filter(source == x)  %>% select(target) %>% unlist() %>% unique()
  })
  names(TFofRec) <- Rec.list

  # get all TF
  TFofALL <- RecTF.DB %>% select(target) %>% unlist() %>% unique()

  # perform fisher test
  Recs <- lapply(TFofRec, function(x){fisher_test(subset1 = x, subset2 = TF.list, backgrond = TFofALL)})
  Recs <- unlist(Recs)
  Recs <- names(Recs)[Recs <= 0.05]
  Recs <- Recs[Recs %in% target_gene]

  # get activated RecTF pairs
  RecTFList <- TFofRec[Recs]
  RecTFList <- lapply(RecTFList, function(x){intersect(x, TF.list)})
  RecTFList <- paste(rep(Recs, times = lengths(RecTFList)), unlist(RecTFList), sep = "_")

  # check result
  if(length(RecTFList)==0)
    stop("Error: No significant RecTF pairs")

  # get result
  RecTFTable <- RecTFList %>% strsplit(.,split = "_") %>% do.call(rbind, .) %>% as.data.frame()
  colnames(RecTFTable) <- c("source","target")

  cat(paste0("get ",length(RecTFList)," activated RecTF pairs\n"))
  return(RecTFTable)

}

#' @title Generate Multi-layer Signal Networks
#'
#' @description
#' This function constructs the Ligand_Receptor, Receptor_TF, TF_TarGene networks between the central cell and neighboring cells according to scRNA-Seq expression matrix and barcode table
#'
#' @param data scRNA-seq data. The gene expression matrix（raw) with rows as genes (gene symbols) and columns as cells.
#' @param BarCluTable The annotation results for clustering. The first column is barcode and the second is cell type.
#' @param RecClu character: The central cell
#' @param LigClu character: The neighboring cell
#' @param abundant.cutoff Screening threshold for high expressed gene in dataset.
#' @param abs_logFC Screening threshold for differentially expressed genes in dataset.
#' @param min_pct Screening threshold for FindMarkers in Seurat. The default setting is 0.05.
#' @param pval Screening threshold for FindMarkers in Seurat. The default setting is 0.05.
#' @param logfc Screening threshold for FindMarkers in Seurat. The default setting is 0.15.
#' @param Raw.data Whether the matrix is normalized or not.
#' @param min.cells Include features detected in at least this many cells.
#' @param min.features Include cells where at least this many features are detected.
#' @param LigRec.DB The database of Ligand-Receptor interactions.
#' @param TFTG.DB The database of TF-TarFget gene interactions.
#' @param RecTF.DB The database of Receptor-TF interactions.
#'
#' @import Seurat
#' @import dplyr
#' @import Matrix
#' @importFrom methods as
#' @importFrom utils read.table
#'
#' @export
#'
#' @return
#' A list consists of the Ligand_Receptor, Receptor_TF and TF_TarGene signaling subnetwork.
#' The signaling subnetwork is returned as a dataframe object, including three columns:
#' the first column is molecule A, and the second column is molecule B.
#' There is an interaction between the molecules A and B, which correspond to the ligand, receptor,
#' transcription factor or target gene. The third column is used to visualize the signaling subnetwork.
RunMLnet <- function(data, BarCluTable, RecClu, LigClu,
                     abundant.cutoff = 0.01, abs_logFC = 1,
                     Raw.data = TRUE, min.cells = 3, min.features = 200,
                     pval = 0.05, logfc = 0.15, min_pct = 0.05,
                     LigRec.DB, RecTF.DB, TFTG.DB){

  requireNamespace("Seurat")
  requireNamespace("dplyr")

  ## check ##
  if (class(data)[1] == "matrix" & class(data)[1] == "dgCMatrix")
    stop("data must be a matrix or sparse matrix")
  if (!is.data.frame(BarCluTable))
    stop("BarCluTable must be a data frame or tibble object")
  if (!('Barcode' %in% colnames(BarCluTable)))
    stop("BarCluTable must contain a column named 'Barcode'")
  if (!('Cluster' %in% colnames(BarCluTable)))
    stop("BarCluTable must contain a column named 'Cluster'")
  if (!(LigClu %in% unique(BarCluTable$Cluster)) & !(RecClu %in% unique(BarCluTable$Cluster)))
    stop("BarCluTable and RecClu must be a character in Cluster colunm of BarCluTable")

  ## keep the same barcodes order
  allCell <- intersect(colnames(data), BarCluTable$Barcode)
  data <- data[,allCell]
  BarCluTable <- BarCluTable[match(allCell,BarCluTable$Barcode),]

  ## filter ##
  # calculate mean
  all_mean <- rowMeans(data)

  # filter genes on the number of cells expressing (eg.3)
  if (min.cells > 0) {
    num.cells <- Matrix::rowSums(x = data > 0)
    data <- data[which(x = num.cells >= min.cells), ]
  }
  # Filter cells based on min.features (eg.200)
  if (min.features > 0) {
    nfeatures <- Matrix::colSums(x = data > 0)
    data <- data[, which(x = nfeatures >= min.features)]
  }

  # update BarCluTable
  BarCluTable <- BarCluTable[match(colnames(data),BarCluTable$Barcode),]

  ## normalization ##
  if(Raw.data){
    cat("perform normalization\n")
    GCMat = runNormalize(data, norm.method = "LogNormalize")
  }else{
    GCMat = data
  }

  ## get DEGs of source cells and target cells ##
  source_deg_tab <- getDiffExpGene(GCMat, BarCluTable, Clus = LigClu, min_pct = min_pct,
                                   logfc.cutoff = logfc, p_val.cutoff = pval, Test.methods = "t")
  target_deg_tab <- getDiffExpGene(GCMat, BarCluTable, Clus = RecClu, min_pct = min_pct,
                                   logfc.cutoff = logfc, p_val.cutoff = pval, Test.methods = "t")

  ## get LigRec pairs ##
  source_up <- source_deg_tab %>% dplyr::filter(p_val_adj <= 0.05 & avg_logFC > 0) %>% rownames()
  target_abundant <- names(all_mean)[all_mean > abundant.cutoff]
  LigRecTab <- getLigRec(LigRec.DB, source_up, target_abundant)

  ## get TFTG pairs ##
  target_gene <- rownames(GCMat)
  target_deg <- target_deg_tab %>% dplyr::filter(p_val_adj <= 0.05 & abs(avg_logFC) > abs_logFC) %>% rownames()
  TFTGTab <- getTFTG(TFTG.DB, target_deg, target_gene)

  ## get RecTF pairs ##
  Rec.list <- getNodeList(LigRecTab, "target")
  TF.list <- getNodeList(TFTGTab, "source")
  RecTFTab <- getRecTF(RecTF.DB, Rec.list, TF.list, target_gene)

  ## updata ##
  Receptors_in_Tab <- getNodeList(RecTFTab, "source")
  LigRecTab <- LigRecTab[LigRecTab[,2] %in% Receptors_in_Tab,]

  TFs_in_Tab <- getNodeList(RecTFTab, "target")
  TFTGTab <- TFTGTab[TFTGTab[,1] %in% TFs_in_Tab,]

  ## output
  LigRecTab$key <- paste(LigRecTab$source, LigRecTab$target, sep = "_")
  RecTFTab$key <- paste(RecTFTab$source, RecTFTab$target, sep = "_")
  TFTGTab$key <- paste(TFTGTab$source, TFTGTab$target, sep = "_")
  result <- list("LigRec" = LigRecTab,
                 "RecTF" = RecTFTab,
                 "TFTar" = TFTGTab)

  cat("Final LR pairs:",nrow(LigRecTab))
  cat("\nFinal RecTF pairs:",nrow(RecTFTab))
  cat("\nFinal TFTG pairs:",nrow(TFTGTab))

  return(result)

}
